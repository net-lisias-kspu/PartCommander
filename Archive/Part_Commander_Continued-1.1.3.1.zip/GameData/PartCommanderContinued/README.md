# Part Commander
Plugin for Kerbal Space Program (KSP).  Access the right-click action menus from all parts on the current vessel in a single consolidated interface.

Copyright 2016, Sean McDougall

Github: https://github.com/linuxgurugamer/PartCommander
Old GitHub: https://github.com/seanmcdougall/PartCommander

INSTALLATION

Copy the "PartCommanderContinued" folder and all its contents into your KSP/GameData folder.



ACKNOWLEDGEMENTS
- Icons made by Freepik (http://www.flaticon.com/authors/freepik) from www.flaticon.com are licensed by CC BY 3.0 (http://creativecommons.org/licenses/by/3.0/)
- TriggerAU for his KSPPluginFramework (https://github.com/TriggerAu/KSPPluginFramework)
